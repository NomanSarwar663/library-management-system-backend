const {register, login} = require("./auth.service")

const authService = {
    register,
    login,
}

module.exports = {
    authService
}
