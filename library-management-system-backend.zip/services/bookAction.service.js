const { createResponse, formatResponse } = require("../helpers/utility");
const validate = require("../helpers/validationSchema");
const { BaseError } = require("../helpers/ErrorHandling");
const book = require("../model/book");
const bookHistory = require("../model/bookHistory");

const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

async function checkIn() {
  //   await User.create({
  //     firstName,
  //     lastName,
  //     email: email.toLowerCase(), // sanitize: convert email to lowercase
  //     password: await bcrypt.hash(password, 10),
  //   });

  return formatResponse(200, "Success", "Book Check-in");
}

async function checkOut(data) {
  //   const { email, password } = data;

  //   if (!(email && password)) {
  //     throw new BaseError("Email and password is required", 404);
  //   }
  //   const user = await User.findOne({ email });
  //   console.log(process.env.JWT_TOKEN_KEY)
  //   if (user && (await bcrypt.compare(password, user.password))) {
  //     token = jwt.sign(
  //       { _id: user._id, role: user.role, email: user.email },
  //       process.env.JWT_TOKEN_KEY,
  //       {
  //         expiresIn: "48h",
  //       }
  //     );

  //     return formatResponse(200, "Success", "Login Successfully", {
  //       token,
  //       user,
  //     });
  //   }
  //   throw new BaseError("Invalid credentials", 404);

  return formatResponse(200, "Success", "Book Check-out");
}

module.exports = {};
