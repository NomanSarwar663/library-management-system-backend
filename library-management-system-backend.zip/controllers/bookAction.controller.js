const { bookActionService } = require("../services");
const { formatResponse } = require("../helpers/utility");

async function checkIn(req, res) {
  try {
    const response = await bookActionService.checkIn();
    if (response) {
      return res.status(response.statusCode).json(response);
    }
  } catch (error) {
    const { message, statusCode } = error;
    res
      .status(statusCode || 400)
      .json(formatResponse(statusCode || 400, "error", message));
  }
}

async function checkOut(req, res) {
  try {
    const response = await bookActionService.checkOut(req.body);
    if (response) {
      return res.status(response.statusCode).json(response);
    }
  } catch (error) {
    const { message, statusCode } = error;
    res
      .status(statusCode || 400)
      .json(formatResponse(statusCode || 400, "error", message));
  }
}
